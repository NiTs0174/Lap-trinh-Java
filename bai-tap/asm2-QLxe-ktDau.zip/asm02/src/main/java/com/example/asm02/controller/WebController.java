package com.example.asm02.controller;


import com.example.asm02.model.Car;
import com.example.asm02.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class WebController {

    @Autowired
    private CarService carService;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("cars", carService.getAllCars());
        return "index";
    }

    @GetMapping("/add")
    public String addCarForm(Model model) {
        model.addAttribute("car", new Car());
        return "addCar";
    }

    @PostMapping("/add")
    public String addCarSubmit(@ModelAttribute Car car) {
        carService.addCar(car);
        return "redirect:/";
    }

    @GetMapping("/update/{id}")
    public String updateCarForm(@PathVariable Long id, Model model) {
        Car car = carService.getAllCars().stream().filter(c -> c.getId().equals(id)).findFirst().orElse(null);
        model.addAttribute("car", car);
        return "updateCar";
    }

    @PostMapping("/update")
    public String updateCarSubmit(@ModelAttribute Car car) {
        carService.updateCar(car.getId(), car);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
        return "redirect:/";
    }

    @GetMapping("/search")
    public String searchCarForm() {
        return "searchCar";
    }

    @GetMapping("/search/result")
    public String searchCarResult(@RequestParam String criteria, @RequestParam String value, Model model) {
        List<Car> result;
        switch (criteria) {
            case "beautiful":
                result = carService.findBeautifulLicensePlates();
                break;
            case "seatCount":
                result = carService.findBySeatCount(Integer.parseInt(value));
                break;
            case "productionYear":
                result = carService.findByProductionYear(Integer.parseInt(value));
                break;
            default:
                result = List.of();
        }
        model.addAttribute("cars", result);
        return "index";
    }

    @GetMapping("/CheckString")
    public String CheckString() {
        return "CheckString"; // Trả về trang index.html
    }
}
