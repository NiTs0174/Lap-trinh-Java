package com.example.asm02.service;

import com.example.asm02.model.Car;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CarServiceImpl implements CarService {
    private List<Car> cars = new ArrayList<>();
    private Long nextId = 1L;

    // Adding sample data
    public CarServiceImpl() {
        cars.add(new Car(nextId++, "1234-11111", LocalDate.of(2020, 1, 1), 4, true));
        cars.add(new Car(nextId++, "5678-22222", LocalDate.of(2019, 5, 20), 7, false));
        cars.add(new Car(nextId++, "4321-33333", LocalDate.of(2021, 7, 15), 4, true));
        cars.add(new Car(nextId++, "1357-24680", LocalDate.of(2023, 4, 29), 2, false));
    }

    @Override
    public List<Car> getAllCars() {
        return cars;
    }

    @Override
    public Car addCar(Car car) {
        car.setId(nextId++);
        cars.add(car);
        return car;
    }

    @Override
    public void deleteCar(Long id) {
        cars.removeIf(car -> car.getId().equals(id));
    }

    @Override
    public Car updateCar(Long id, Car car) {
        Optional<Car> existingCarOpt = cars.stream().filter(c -> c.getId().equals(id)).findFirst();
        if (existingCarOpt.isPresent()) {
            Car existingCar = existingCarOpt.get();
            existingCar.setLicensePlate(car.getLicensePlate());
            existingCar.setProductionDate(car.getProductionDate());
            existingCar.setSeatCount(car.getSeatCount());
            existingCar.setBusinessRegistration(car.getBusinessRegistration());
            return existingCar;
        }
        return null; // Or throw an exception
    }

    @Override
    public List<Car> findBeautifulLicensePlates() {
        return cars.stream()
                .filter(car -> isBeautifulLicensePlate(car.getLicensePlate()))
                .collect(Collectors.toList());
    }

    @Override
    public List<Car> findBySeatCount(int seatCount) {
        return cars.stream()
                .filter(car -> car.getSeatCount() == seatCount)
                .collect(Collectors.toList());
    }

    @Override
    public List<Car> findByProductionYear(int year) {
        return cars.stream()
                .filter(car -> car.getProductionDate().getYear() == year)
                .collect(Collectors.toList());
    }

    private boolean isBeautifulLicensePlate(String licensePlate) {
        String[] parts = licensePlate.split("-");
        String yyyyy = parts[1];
        return hasAtLeastFourIdenticalDigits(yyyyy) || isSequential(yyyyy);
    }

    private boolean hasAtLeastFourIdenticalDigits(String s) {
        for (char c : s.toCharArray()) {
            if (s.chars().filter(ch -> ch == c).count() >= 4) {
                return true;
            }
        }
        return false;
    }

    private boolean isSequential(String s) {
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) + 1 != s.charAt(i + 1)) {
                return false;
            }
        }
        return true;
    }
}
