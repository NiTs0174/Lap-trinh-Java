package com.example.asm02.service;

import com.example.asm02.model.Car;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CarService {
    List<Car> getAllCars();
    Car addCar(Car car);
    void deleteCar(Long id);
    Car updateCar(Long id, Car car);
    List<Car> findBeautifulLicensePlates();
    List<Car> findBySeatCount(int seatCount);
    List<Car> findByProductionYear(int year);
}
