package com.example.asm02.model;

import java.time.LocalDate;

public class Car {
    private Long id;
    private String licensePlate;
    private LocalDate productionDate;
    private int seatCount;
    private Boolean businessRegistration;

    // Constructors, getters, and setters
    public Car() {}

    public Car(Long id, String licensePlate, LocalDate productionDate, int seatCount, Boolean businessRegistration) {
        this.id = id;
        this.licensePlate = licensePlate;
        this.productionDate = productionDate;
        this.seatCount = seatCount;
        this.businessRegistration = businessRegistration;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public LocalDate getProductionDate() {
        return productionDate;
    }

    public void setProductionDate(LocalDate productionDate) {
        this.productionDate = productionDate;
    }

    public int getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(int seatCount) {
        this.seatCount = seatCount;
    }

    public Boolean getBusinessRegistration() {
        return businessRegistration;
    }

    public void setBusinessRegistration(Boolean businessRegistration) {
        this.businessRegistration = businessRegistration;
    }
}
