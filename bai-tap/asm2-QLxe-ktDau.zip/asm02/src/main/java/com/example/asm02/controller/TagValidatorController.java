package com.example.asm02.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

@RestController
public class TagValidatorController {
    @PostMapping("/CheckString")
    public String CheckString(@RequestBody String str) {
        if (isValid(str)) {
            return "Ok";
        } else {
            return "Not Ok";
        }
    }

    private boolean isValid(String str) {
        Stack<Character> stack = new Stack<>();
        Map<Character, Character> matchingTags = new HashMap<>();
        matchingTags.put('}', '{');
        matchingTags.put(')', '(');
        matchingTags.put(']', '[');
        matchingTags.put('>', '<');

        for (char ch : str.toCharArray()) {
            if (matchingTags.containsValue(ch)) { // Nếu là thẻ mở
                stack.push(ch);
            } else if (matchingTags.containsKey(ch)) { // Nếu là thẻ đóng
                if (stack.isEmpty() || stack.pop() != matchingTags.get(ch)) {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }
}
