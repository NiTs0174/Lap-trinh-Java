package com.example.asm02.controller;

import com.example.asm02.model.Car;
import com.example.asm02.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
public class CarController {
    @Autowired
    private CarService carService;

    public CarController(CarService carService) {
        this.carService = carService;
    }

    @GetMapping
    public List<Car> getAllCars() {
        return carService.getAllCars();
    }

    @PostMapping
    public Car addCar(@RequestBody Car car) {
        return carService.addCar(car);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCar(@PathVariable Long id) {
        carService.deleteCar(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public Car updateCar(@PathVariable Long id, @RequestBody Car car) {
        return carService.updateCar(id, car);
    }

    @GetMapping("/search/beautiful-license-plates")
    public List<Car> findBeautifulLicensePlates() {
        return carService.findBeautifulLicensePlates();
    }

    @GetMapping("/search/seat-count")
    public List<Car> findBySeatCount(@RequestParam int seatCount) {
        return carService.findBySeatCount(seatCount);
    }

    @GetMapping("/search/production-year")
    public List<Car> findByProductionYear(@RequestParam int year) {
        return carService.findByProductionYear(year);
    }
}
