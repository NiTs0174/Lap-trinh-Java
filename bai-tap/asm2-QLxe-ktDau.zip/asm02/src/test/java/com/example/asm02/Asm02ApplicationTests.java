package com.example.asm02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asm02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
