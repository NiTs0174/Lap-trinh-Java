package laptrinhungdungjava.DemoJPA2.repository;

import laptrinhungdungjava.DemoJPA2.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer> {
}
