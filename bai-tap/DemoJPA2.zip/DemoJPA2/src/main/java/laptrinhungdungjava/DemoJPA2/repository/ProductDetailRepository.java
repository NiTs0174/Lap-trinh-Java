package laptrinhungdungjava.DemoJPA2.repository;

import laptrinhungdungjava.DemoJPA2.model.ProductDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductDetailRepository extends JpaRepository<ProductDetail, Integer> {
}
