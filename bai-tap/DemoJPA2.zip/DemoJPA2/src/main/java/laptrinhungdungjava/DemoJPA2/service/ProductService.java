package laptrinhungdungjava.DemoJPA2.service;

import laptrinhungdungjava.DemoJPA2.model.Category;
import laptrinhungdungjava.DemoJPA2.model.Product;
import laptrinhungdungjava.DemoJPA2.model.ProductDetail;
import laptrinhungdungjava.DemoJPA2.repository.CategoryRepository;
import laptrinhungdungjava.DemoJPA2.repository.ProductDetailRepository;
import laptrinhungdungjava.DemoJPA2.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ProductDetailRepository  productDetailRepository;
    @Autowired
    private CategoryRepository categoryRepository;
    public List<Product> getAll() {
        List<Product> listProduct =  productRepository.findAll();
        return listProduct;
    }
    public Product get(int id) {
        Product p =  productRepository.findById(id).orElse(null);
        return p;
    }
    public void add(Product newProduct) {
        Category c = newProduct.getCategory();
        productRepository.save(newProduct);
    }
    public void update(Product editProduct)
    {
        Product find = get(editProduct.getId());
        if(find!= null) {
            find.setPrice(editProduct.getPrice());
            find.setName(editProduct.getName());
            if(editProduct.getImage()!= null)
                find.setImage(editProduct.getImage());
            productRepository.saveAndFlush(find);
            ProductDetail productDetail = editProduct.getProductDetail();
            if(productDetail!= null)
            {
                productDetail.setId(find.getId());
                productDetailRepository.save(productDetail);
            }
        }
    }
    public void updateImage(Product newProduct, MultipartFile imageProduct)
    {
        if (!imageProduct.isEmpty()) {
            try
            {
                Path dirImages = Paths.get("static/images");
                if (!Files.exists(dirImages)) {
                    Files.createDirectories(dirImages);
                }
                String newFileName = UUID.randomUUID() + "_" + imageProduct.getOriginalFilename();
                Path pathFileUpload = dirImages.resolve(newFileName);
                Files.copy(imageProduct.getInputStream(), pathFileUpload, StandardCopyOption.REPLACE_EXISTING);
                newProduct.setImage(newFileName);
            }
            catch (IOException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }
    }

}
