package com.example.ASM6.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@RequiredArgsConstructor
@AllArgsConstructor
@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotBlank(message = "Tên Giảng viên không được để trống")
//    private String lecture_name;

    @NotBlank(message = "Nơi học không được để trống")
    private String place;

//    @NotBlank(message = "Ngày bắt đầu không được để trống")
    private LocalDateTime start_date;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "lecture_id")
    private User user;

    @OneToMany(mappedBy = "course")
    private Set<Attendance> attendance;
}
