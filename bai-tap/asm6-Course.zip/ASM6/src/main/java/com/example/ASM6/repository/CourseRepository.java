package com.example.ASM6.repository;

import com.example.ASM6.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    @Query("SELECT c FROM Course c WHERE c.start_date > CURRENT_TIMESTAMP")
    List<Course> findUpcomingCourses();

    @Query("SELECT c FROM Course c WHERE LOWER(c.user.name) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<Course> findCoursesByLectureName(@Param("searchTerm") String searchTerm);
}
