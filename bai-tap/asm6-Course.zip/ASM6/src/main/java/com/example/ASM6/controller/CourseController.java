package com.example.ASM6.controller;

import com.example.ASM6.model.Course;
import com.example.ASM6.repository.CourseRepository;
import com.example.ASM6.service.CategoryService;
import com.example.ASM6.service.CourseService;
import com.example.ASM6.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private CourseRepository courseRepository;
    @Autowired
    private UserService userService;

    @GetMapping
    public String showCourseList(Model model) {
        model.addAttribute("courses", courseService.getAllCourses());
        return "/courses/courses-list";
    }

    //Lấy ds khóa học sắp tới + Tìm tên giảng viên
    @GetMapping("/home")
    public String home(Model model, @RequestParam(name = "search", required = false) String search) {
        List<Course> courses;
        if (search != null && !search.isEmpty()) {
            courses = courseService.searchCoursesByLectureName(search);
        } else {
            courses = courseService.getUpcomingCourses();
        }
        model.addAttribute("upcomingCourses", courses);
        return "/courses/home";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("categories", categoryService.getAllCategories());
        return "/courses/add-course";
    }

    @PostMapping("/add")
    public String addCourse(@Valid Course course, BindingResult result) {
        if (result.hasErrors()) {
            return "/courses/add-course";
        }
        courseService.addCourse(course);
        return "redirect:/courses";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Course course = courseService.getCourseById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course Id:" + id));
        model.addAttribute("course", course);
        model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("categories", categoryService.getAllCategories());
        return "/courses/update-course";
    }

    @PostMapping("/update/{id}")
    public String updateCourse(@PathVariable Long id, @Valid Course course,
                                BindingResult result) {
        if (result.hasErrors()) {
            course.setId(id);
            return "/courses/update-course";
        }
        courseService.updateCourse(course);
        return "redirect:/courses";
    }

    @GetMapping("/delete/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteCourseById(id);
        return "redirect:/courses";
    }

}
