package com.example.ASM6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asm6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
