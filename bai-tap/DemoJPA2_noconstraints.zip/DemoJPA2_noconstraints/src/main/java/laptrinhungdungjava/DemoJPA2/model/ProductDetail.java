package laptrinhungdungjava.DemoJPA2.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity
public class ProductDetail {
    @Id
    private int id;

    private String description;
    private int manufactureYear;
    private String manufacturer;
    //etc..
}


