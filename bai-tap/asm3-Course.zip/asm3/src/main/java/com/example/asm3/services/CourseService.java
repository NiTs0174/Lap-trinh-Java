package com.example.asm3.services;

import com.example.asm3.models.Course;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class CourseService {
    private List<Course> listCourse = new ArrayList<>();

    public CourseService() {
        // Thêm các khóa học mẫu
        listCourse.add(new Course(1, "Java Programming", "Room 101", LocalDate.of(2024, 6, 1)));
        listCourse.add(new Course(2, "Spring Boot", "Room 102", LocalDate.of(2024, 7, 1)));
        listCourse.add(new Course(3, "Web Development", "Room 103", LocalDate.of(2024, 8, 1)));
    }

    public void add(Course newProduct) {listCourse.add(newProduct);}
    public List<Course> GetAll() {return listCourse;}
}
