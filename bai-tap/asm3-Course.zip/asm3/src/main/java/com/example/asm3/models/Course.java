package com.example.asm3.models;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.Getter;

import java.time.LocalDate;

@Setter
@Getter
@RequiredArgsConstructor
@AllArgsConstructor
public class Course {
    private int id;
    private String lectureName;
    private String place;
    private LocalDate startDate;
}
