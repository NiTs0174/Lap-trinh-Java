package com.example.ASM6.repository;

import com.example.ASM6.model.Attendance;
import com.example.ASM6.model.Course;
import com.example.ASM6.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    Optional<Attendance> findByCourseAndUser(Course course, User user);
    boolean existsByCourseAndUser(Course course, User user);
    List<Attendance> findByUser(User user);

    @Query("SELECT a.course FROM Attendance a WHERE a.user = :user")
    List<Course> findCoursesByUser(User user);
}
