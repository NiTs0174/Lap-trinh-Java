package com.example.ASM6.controller;

import com.example.ASM6.model.Course;
import com.example.ASM6.model.Following;
import com.example.ASM6.model.User;
import com.example.ASM6.service.*;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private UserService userService;
    @Autowired
    private AttendanceService attendanceService;
    @Autowired
    private FollowingService followingService;

    @GetMapping
    public String showCourseList(Model model) {
        model.addAttribute("courses", courseService.getAllCourses());
        return "/courses/courses-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model, @AuthenticationPrincipal UserDetails currentUser) {
        model.addAttribute("course", new Course());
        //model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("categories", categoryService.getAllCategories());

        return "/courses/add-course";
    }

    @PostMapping("/add")
    public String addCourse(@Valid Course course, BindingResult result, @AuthenticationPrincipal UserDetails currentUser) {
        if (result.hasErrors()) {
            return "/courses/add-course";
        }
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        course.setUser(user);
        courseService.addCourse(course);
        return "redirect:/courses/home";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, @AuthenticationPrincipal UserDetails currentUser) {
        Course course = courseService.getCourseById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course Id:" + id));
        model.addAttribute("course", course);
        //model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("categories", categoryService.getAllCategories());
        return "/courses/update-course";
    }

    @PostMapping("/update/{id}")
    public String updateCourse(@PathVariable Long id, @Valid Course course,
                                BindingResult result, @AuthenticationPrincipal UserDetails currentUser) {
        if (result.hasErrors()) {
            course.setId(id);
            return "/courses/update-course";
        }
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        course.setUser(user);
        courseService.updateCourse(course);
        return "redirect:/courses/home";
    }

    @GetMapping("/delete/{id}")
    public String deleteCourse(@PathVariable Long id) {
        courseService.deleteCourseById(id);
        return "redirect:/courses/home";
    }

    //HOME chưa đăng nhập
    @GetMapping("/homeNoAuthenticated")
    public String homeNoAuthenticated(Model model, @RequestParam(name = "search", required = false) String search) {
        List<Course> courses;
        //------Lấy ds khóa học sắp tới + Tìm tên giảng viên-------
        if (search != null && !search.isEmpty()) {
            courses = courseService.searchCoursesByLectureName(search);
        } else {
            courses = courseService.getUpcomingCourses();
        }
        model.addAttribute("upcomingCourses", courses);

        return "/courses/homeNoAuthenticated";
    }

    //HOME đã đăng nhập
    @GetMapping("/home")
    public String home(Model model, @RequestParam(name = "search", required = false) String search, @AuthenticationPrincipal UserDetails currentUser) {
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        List<Course> courses = courseService.getCoursesByUser(user);

        //------Lấy ds khóa học sắp tới + Tìm tên giảng viên-------
        if (search != null && !search.isEmpty()) {
            courses = courseService.searchCoursesByLectureName(search);
        } else {
            courses = courseService.getUpcomingCourses();
        }
        model.addAttribute("upcomingCourses", courses);

        //----THAM GIA KHÓA HỌC---------
        // Thêm danh sách trạng thái tham gia cho các khóa học
        Map<Long, Boolean> courseAttendanceStatus = new HashMap<>();
        for (Course course : courses) {
            boolean isGoing = attendanceService.isUserAttendingCourse(course, user);
            courseAttendanceStatus.put(course.getId(), isGoing);
            // Thêm thông tin "Following" cho từng giảng viên
            Optional<Following> following = followingService.findByFollowerAndFollowee(user, course.getUser());
            course.setFollowing(following.orElse(null));
        }
        model.addAttribute("courseAttendanceStatus", courseAttendanceStatus);
        model.addAttribute("currentUser", user);

        return "/courses/home";
    }

    //MY COURSE
    @GetMapping("/mine")
    public String showMyCourses(Model model, Authentication authentication) {
        String username = authentication.getName();
        User user = userService.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        List<Course> myCourses = courseService.getCoursesByUser(user);
        model.addAttribute("myCourses", myCourses);
        return "/courses/mine";
    }

    //ATTENDENCE
    @GetMapping("/join/{id}")
    public String joinCourse(@PathVariable Long id, @AuthenticationPrincipal UserDetails currentUser) {
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        Course course = courseService.getCourseById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course Id:" + id));

        attendanceService.addAttendance(course, user);
        return "redirect:/courses/home";
    }

    @GetMapping("/leave/{id}")
    public String leaveCourse(@PathVariable Long id, @AuthenticationPrincipal UserDetails currentUser) {
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        Course course = courseService.getCourseById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid course Id:" + id));

        attendanceService.removeAttendance(course, user);
        return "redirect:/courses/home";
    }

    @GetMapping("/attending")
    public String coursesUserIsGoing(Model model, @AuthenticationPrincipal UserDetails currentUser) {
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        List<Course> courses = courseService.getCoursesByUser(user);
        // Thêm danh sách trạng thái tham gia cho các khóa học
        Map<Long, Boolean> courseAttendanceStatus = new HashMap<>();
        for (Course course : courses) {
            boolean isGoing = attendanceService.isUserAttendingCourse(course, user);
            courseAttendanceStatus.put(course.getId(), isGoing);
        }
        model.addAttribute("courseAttendanceStatus", courseAttendanceStatus);
        model.addAttribute("currentUser", user);

        List<Course> goingCourses = attendanceService.getCoursesUserIsAttending(user);
        model.addAttribute("goingCourses", goingCourses);
        return "/courses/attending";
    }

    //FOLLOW
    @GetMapping("/follow/{followeeId}")
    public String follow(@AuthenticationPrincipal UserDetails currentUser,
                         @PathVariable("followeeId") Long followeeId) {
        User follower = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        User followee = userService.findById(followeeId)
                .orElseThrow(() -> new UsernameNotFoundException("Followee not found"));
        followingService.follow(follower, followee);

        return "redirect:/courses/home";
    }

    @GetMapping("/unfollow/{followeeId}")
    public String unfollow(@AuthenticationPrincipal UserDetails currentUser,
                           @PathVariable("followeeId") Long followeeId) {
        User follower = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        User followee = userService.findById(followeeId)
                .orElseThrow(() -> new UsernameNotFoundException("Followee not found"));
        followingService.unfollow(follower, followee);

        return "redirect:/courses/home";
    }

    @GetMapping("/following")
    public String coursesUserIsFollowing(Model model, @AuthenticationPrincipal UserDetails currentUser) {
        User user = userService.findByUsername(currentUser.getUsername())
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        List<Course> courses = courseService.getCoursesByUser(user);
        Map<Long, Boolean> courseAttendanceStatus = new HashMap<>();
        for (Course course : courses) {
            // Thêm thông tin "Following" cho từng giảng viên
            Optional<Following> following = followingService.findByFollowerAndFollowee(user, course.getUser());
            course.setFollowing(following.orElse(null));
        }
        model.addAttribute("courseAttendanceStatus", courseAttendanceStatus);
        model.addAttribute("currentUser", user);

        List<Course> followingCourses = followingService.getCoursesUserIsFollowing(user);
        model.addAttribute("followingCourses", followingCourses);

        return "courses/following";
    }
}
