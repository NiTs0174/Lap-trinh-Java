package com.example.ASM6.service;

import com.example.ASM6.model.Attendance;
import com.example.ASM6.model.Course;
import com.example.ASM6.model.User;
import com.example.ASM6.repository.AttendanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class AttendanceService {

    @Autowired
    private AttendanceRepository attendanceRepository;

    @Transactional
    public void addAttendance(Course course, User user) {
        Attendance attendance = new Attendance(course, user);
        attendanceRepository.save(attendance);
    }

    @Transactional
    public void removeAttendance(Course course, User user) {
        Optional<Attendance> attendance = attendanceRepository.findByCourseAndUser(course, user);
        attendance.ifPresent(attendanceRepository::delete);
    }

    public boolean isUserAttendingCourse(Course course, User user) {
        return attendanceRepository.existsByCourseAndUser(course, user);
    }

    public List<Course> getCoursesUserIsAttending(User user) {
        return attendanceRepository.findCoursesByUser(user);
    }
}

