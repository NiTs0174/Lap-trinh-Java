package com.example.ASM6.service;

import com.example.ASM6.model.Course;
import com.example.ASM6.model.User;
import com.example.ASM6.repository.CourseRepository;
import com.example.ASM6.repository.UserRepository;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class CourseService {

    @Autowired
    private final CourseRepository courseRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AttendanceService attendanceService;

    // Retrieve all Course from the database
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    // Retrieve a Course by its id
    public Optional<Course> getCourseById(Long id) {
        return courseRepository.findById(id);
    }

    public Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    // Add a new Course to the database
    public Course addCourse(Course course) {
        return courseRepository.save(course);
    }

    // Update an existing Course
    public Course updateCourse(@NotNull Course course) {
        Course existingCourse = courseRepository.findById(course.getId())
                .orElseThrow(() -> new IllegalStateException("Course with ID " +
                        course.getId() + " does not exist."));
//        existingCourse.setLecture_name(course.getLecture_name);
        existingCourse.setUser(course.getUser());
        existingCourse.setPlace(course.getPlace());
        existingCourse.setStart_date(course.getStart_date());
        existingCourse.setCategory(course.getCategory());
        return courseRepository.save(existingCourse);
    }

    // Delete a product by its id
    public void deleteCourseById(Long id) {
        if (!courseRepository.existsById(id)) {
            throw new IllegalStateException("Course with ID " + id + " does not exist.");
        }
        courseRepository.deleteById(id);
    }

    //Lấy ds khóa học sắp tới
    public List<Course> getUpcomingCourses() {
        return courseRepository.findUpcomingCourses();
    }

    //Tìm tên giảng viên
    public List<Course> searchCoursesByLectureName(String searchTerm) {
        return courseRepository.findCoursesByLectureName(searchTerm);
    }

    // Lấy danh sách các khóa học do một người dùng (giảng viên) tạo ra
    public List<Course> getCoursesByUser(User user) {
        return courseRepository.findByUser(user);
    }

    public List<Course> getCoursesByUsers(List<User> users) {
        return courseRepository.findByUserIn(users);
    }
}
