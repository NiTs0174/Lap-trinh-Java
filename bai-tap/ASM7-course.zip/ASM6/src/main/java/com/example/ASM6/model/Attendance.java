package com.example.ASM6.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@Entity
public class Attendance {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;

   @ManyToOne
   @JoinColumn(name = "course_id")
   private Course course;

   @ManyToOne
   @JoinColumn(name = "attendee")
   private User user;

   // Constructors
   public Attendance(){}

   public Attendance(Course course, User user) {
      this.course = course;
      this.user = user;
   }
}
