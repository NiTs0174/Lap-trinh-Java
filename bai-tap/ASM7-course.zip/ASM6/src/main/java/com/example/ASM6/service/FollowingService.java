package com.example.ASM6.service;

import com.example.ASM6.model.Course;
import com.example.ASM6.model.Following;
import com.example.ASM6.model.User;
import com.example.ASM6.repository.CourseRepository;
import com.example.ASM6.repository.FollowingRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FollowingService {

    @Autowired
    private FollowingRepository followingRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private UserService userService;

    public Optional<Following> findByFollowerAndFollowee(User follower, User followee) {
        return followingRepository.findByFollowerAndFollowee(follower, followee);
    }

    @Transactional
    public void follow(User follower, User followee) {
        Following following = new Following();
        following.setFollower(follower);
        following.setFollowee(followee);
        followingRepository.save(following);
    }

    @Transactional
    public void unfollow(User follower, User followee) {
        followingRepository.deleteByFollowerAndFollowee(follower, followee);
    }

    public List<Course> getCoursesUserIsFollowing(User user) {
        List<Following> followings = followingRepository.findByFollower(user);
        List<User> followees = followings.stream().map(Following::getFollowee).collect(Collectors.toList());
        return courseRepository.findByUserIn(followees);
    }

}
