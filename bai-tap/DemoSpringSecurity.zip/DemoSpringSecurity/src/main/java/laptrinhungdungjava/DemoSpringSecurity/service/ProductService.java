package laptrinhungdungjava.DemoSpringSecurity.service;

import laptrinhungdungjava.DemoSpringSecurity.model.Category;
import laptrinhungdungjava.DemoSpringSecurity.model.Product;
import laptrinhungdungjava.DemoSpringSecurity.repository.CategoryRepository;
import laptrinhungdungjava.DemoSpringSecurity.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;
    public List<Product> getAll() {
        List<Product> listProduct =  productRepository.findAll();
        return listProduct;
    }
    public Product get(int id) {
        Product p =  productRepository.findById(id).orElse(null);
        return p;
    }
    public void add(Product newProduct) {
        productRepository.save(newProduct);
    }
    public void update(Product editProduct)
    {
        productRepository.saveAndFlush(editProduct);
    }
    public void updateImage(Product newProduct, MultipartFile imageProduct)
    {
        if (imageProduct!= null && imageProduct.getSize() > 0 ) {
            try
            {
                Path dirImages = Paths.get("target/classes/static/images");
                if (!Files.exists(dirImages)) {
                    Files.createDirectories(dirImages);
                }
                String newFileName = UUID.randomUUID() + "_" + imageProduct.getOriginalFilename();
                Path pathFileUpload = dirImages.resolve(newFileName);
                Files.copy(imageProduct.getInputStream(), pathFileUpload, StandardCopyOption.REPLACE_EXISTING);
                newProduct.setImage(newFileName);
            }
            catch (IOException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }
    }

}
