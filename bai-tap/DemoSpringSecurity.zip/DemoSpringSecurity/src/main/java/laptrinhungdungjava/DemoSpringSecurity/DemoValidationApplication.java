package laptrinhungdungjava.DemoSpringSecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoValidationApplication.class, args);
	}

}
