package laptrinhungdungjava.DemoSpringSecurity.controller;

import jakarta.validation.Valid;
import laptrinhungdungjava.DemoSpringSecurity.model.Product;
import laptrinhungdungjava.DemoSpringSecurity.service.CategoryService;
import laptrinhungdungjava.DemoSpringSecurity.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


@Controller
@RequestMapping("/products")
public class ProductController {
    @Autowired
    private ProductService productService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping()
    public String index(Model model) {
        model.addAttribute("listproduct", productService.getAll());
        return "product/products";
    }
    @GetMapping("/edit/{id}")
    @PreAuthorize("hasAuthority('SALES')")
    public String edit(@PathVariable int id, Model model) {
        Product product = productService.get(id);
        if (product == null) {
            throw new IllegalStateException("Product not found with ID: " + id);
        }
        model.addAttribute("product", product);
        model.addAttribute("categories", categoryService.getAll());
        return "product/edit";
    }

    @PostMapping("/edit")
    @PreAuthorize("hasAuthority('SALES')")
    public String edit(@Valid Product editProduct,
                       BindingResult result,
                       @RequestParam("imageProduct") MultipartFile imageProduct,
                       Model model) {
        if (result.hasErrors()) {
            model.addAttribute("product", editProduct);
            model.addAttribute("categories", categoryService.getAll());
            return "product/edit";
        }
        productService.updateImage(editProduct, imageProduct);
        productService.update(editProduct);
        return "redirect:/products";
    }

    @GetMapping("/AddToCart/{id}")
    @PreAuthorize("hasAuthority('USER')")
    @ResponseBody
    public String addToCart(@PathVariable int id) {
        // Logic to add product with ID productId to the cart
        return "Product with ID " + id + " added to cart successfully";
    }
}