package com.example.MinhThang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhThangApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhThangApplication.class, args);
	}

}
