package com.example.MinhThang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhThangApplicationTests {

	@Test
	void contextLoads() {
	}

}
